package com.example.fooderlich2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
